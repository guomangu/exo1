
      <!-- FOOTER -->
      <footer>
        <p class="pull-right"><a href="#">Haut de page</a></p>
        <p>&copy; 2019 Demo, Centre de réadaptation de Mulhouse. &middot; <a href="#">mentions legales</a> &middot; <a href="#">Plan du  site</a></p>
      </footer>

    </div><!-- /.container -->



    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery-3.2.1.js"></script>
<script src="js/bootstrap.js"></script>
    <script>
    /*  !function ($) {
        $(function(){
          // carousel demo
          $('#myCarousel').carousel()
        })
      }(window.jQuery)*/
    </script>
    
  </body>
</html>
