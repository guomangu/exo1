

<?php
/* HEADER entete avec dépendances CSS 
  ================================================== */
include( "header.php");
 
 
 /*NAVBAR
    ================================================== */
include("menu.php");

 /* Carousel
    ================================================== */

include("slider.php");


   /*  Marketing mainpage 
    ================================================== 
   Wrap the rest of the page in another container to center all the content. */
//$categorie à definir en fonction de la catégorie de bien choisie dans le formulaire.       
 $categorie="A définir";

	    
		 echo'<h1>Liste des biens immobiliers</h1>';
		 
		
		 
		  echo'<form  action="#">
				 <fieldset><legend>Rechercher un Bien immobilier</legend>
				 
				  <div class="form-group">
 <input type="hidden" name="lib_cat" value="'.$categorie.'" id="lib_cat" />
 
 <label for="dept">Choisir le département</label>';
 
 echo '<select name="dep"  id="dep" class="form-control"  style=" max-width:300px">';

 echo '</select>';
 echo' </div>
 <div class="form-group">
 
 <label for="budget">Montant budget maximum</label>
 	<span class="currencyinput">€
<input type="number"  step="10000" id="bugdet" name="budget" placeholder="Budget Max"  min="50000" max="900000000" />
</span>
</div>

<div class="form-group">
 <label for="nbpiece" >Nombre de pièces souhaitées:</label>';
 
 echo '<select name="nbpieces"  id="nbre" class="form-control"  style=" max-width:300px">';
 
 
echo"</select></div>";
  
 echo  '
         <div class="form-group form-button" id="btnsub" >				  
 <button type="submit" class="btn btn-primary" name="envoi">Submit</button>
	</div>
	</fieldset>
	 </form>'; 
	


		  
		
			
include( "acces_membre.php");  
		  
		  
		  
/* Pied de page avec dépendances Javascript...
    ================================================== */
 include( "footer.php");
		  
		  ?>
          
   


